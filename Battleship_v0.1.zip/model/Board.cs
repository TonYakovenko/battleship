using System;
using System.Collections.Generic;
using System.Text;

namespace Battleship.model
{
    public class Board
    {
        const int row = 10;
        const int col = row;

        public static List<List<Spot>> board = new List<List<Spot>>();
        public static string [,] playBoard;

        //TODO Maps should be provided as parameter.
        public void createBoard()
        {
            for(int i=0; i<row; i++)
            {
                List<Spot> boardCol = new List<Spot>();

                for(int j=0; j<col; j++)
                {
                    int id = i*col + j;
                    bool isFilled = Convert.ToBoolean(Maps.map1[id]);
                    Spot sp = new Spot(isFilled);
                    sp.setId(id);
                    boardCol.Add(sp);
                }
                
                board.Add(boardCol);
            }
        }
        public void showBoard()
        {
           Console.ForegroundColor = ConsoleColor.Green;
            System.Console.WriteLine("--------------------");
            StringBuilder sb = new StringBuilder();

            for(int i = 0; i < row; i++)
            {
                for(int j = 0; j < col; j++)
                {
                    sb.Append(" " + board[i][j].showFace());
                }
                sb.AppendLine();
            }
            
            System.Console.WriteLine(sb);
            System.Console.WriteLine("--------------------");
            
        }

        //TODO Nice to have Chars for row and Int for column
        public bool makeShot(int intRow, int intCol)
        {
            Console.Clear();
            board[intRow][intCol].setStatus(false);
            showBoard();
            return board[intRow][intCol].getValue();
        }
    }
}