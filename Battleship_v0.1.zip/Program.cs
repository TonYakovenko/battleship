﻿using System;
using Battleship.model;


namespace Battleship
{
    class Program
    {
        static Board enemyMap = new Board();
        static bool isUserTurn = true;


        static void Main(string[] args)
        {
            Console.Clear();
            enemyMap.createBoard();
            enemyMap.showBoard();
            nextTurn();
  
        }

        static void nextTurn()
        {
            System.Console.WriteLine("Next turn");
            if(isUserTurn)
            {
                bool hitTheAim = userTurn();
                if(hitTheAim)
                {
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    System.Console.WriteLine("Nice Shot!"); 
                    nextTurn();  
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    System.Console.WriteLine("Better luck next time");
                    isUserTurn = false;
                    nextTurn();
                }
            }
            else
            {
                //TODO computer shot
                System.Console.WriteLine("Next turn - computer turn");
                bool hitTheAim = computerTurn();
                if(hitTheAim) isUserTurn = false;
                else isUserTurn = true;
                nextTurn();
            }
        }

        static bool userTurn()
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            System.Console.WriteLine("Please write coordinates:");

            Console.ForegroundColor = ConsoleColor.Green;
            string input = Console.ReadLine();
            string[] inpArr = input.Split(",");
            int inp1 = Int32.Parse(inpArr[0]);
            int inp2 = Int32.Parse(inpArr[1]);
            bool hitTheAim = enemyMap.makeShot(inp1, inp2);

            return hitTheAim;
        }

        static bool computerTurn()
        {
            //TODO Logic for computer guesses
            System.Console.WriteLine("Computer turn!");
            return false;
        }
    }
}
